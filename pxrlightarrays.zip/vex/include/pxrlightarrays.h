/*
Custom functions for converting matrix to string repr,
calculating transformation matrix for different type
of lights
*/

#ifndef __pxrlightarrays_h__
#define __pxrlightarrays_h__

string
matrix_to_string(matrix matx)
{
    string str_trn_matrix = sprintf("%s", matx);
    str_trn_matrix = re_replace(",", " ", str_trn_matrix);
    str_trn_matrix = re_replace("[{}]", "", str_trn_matrix);
    return str_trn_matrix;
}

function void
calc_trn_matrix(vector normal, up;
                export vector dirX, dirY, dirZ;
                export matrix trn_matrix)
{
    dirX = normalize(cross(normal, up));
    dirY = normalize(cross(dirX, normal));
    dirZ = normal;
    trn_matrix = set(dirX, dirY, dirZ);
}

function void
calc_cyl_trn_matrix(vector normal, up;
                    export vector dirX, dirY, dirZ;
                    export matrix trn_matrix)
{
    dirX = normal;
    dirY = normalize(cross(normal, up));
    dirZ = normalize(cross(dirY, normal));
    trn_matrix = set(dirX, dirY, dirZ);
}

#endif

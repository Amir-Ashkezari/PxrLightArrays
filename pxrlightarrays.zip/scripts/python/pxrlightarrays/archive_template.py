"""Light rib Archive template."""


light = """
ObjectBegin "{lightId}"
Transform [ -1 0 -0 0 -0 -1 -0 0 0 0 -1 0 0 0 0 1 ]
Light "{lightType}" "{lightName}" "float intensity" [{intensity}] "float exposure" [{exposure}] "color lightColor" [{lightColor}]{rect_lightMap}
"int enableTemperature" [{enableTemperature}] "float temperature" [{temperature}] "float emissionFocus" [{emissionFocus}]
"int emissionFocusNormalize" [{emissionFocusNormalize}] "color emissionFocusTint" [{emissionFocusTint}] "float specular" [{specular}]
"float diffuse" [{diffuse}] "float intensityNearDist" [{intensityNearDist}] "float coneAngle" [{coneAngle}]
"float coneSoftness" [{coneSoftness}] "string iesProfile" ["{iesProfile}"] "float iesProfileScale" [{iesProfileScale}]
"int iesProfileNormalize" [{iesProfileNormalize}] "int enableShadows" [{enableShadows}] "color shadowColor" [{shadowColor}]
"float shadowDistance" [{shadowDistance}] "float shadowFalloff" [{shadowFalloff}] "float shadowFalloffGamma" [{shadowFalloffGamma}]
"string shadowSubset" ["{shadowSubset}"] "string shadowExcludeSubset" ["{shadowExcludeSubset}"] "int areaNormalize" [{areaNormalize}]
"int traceLightPaths" [{traceLightPaths}] "int thinShadow" [{thinShadow}] "int visibleInRefractionPath" [{visibleInRefractionPath}]
"int cheapCaustics" [{cheapCaustics}] "string cheapCausticsExcludeGroup" ["{cheapCausticsExcludeGroup}"] "int fixedSampleCount" [{fixedSampleCount}]
"string lightGroup" ["{lightGroup}"] "float importanceMultiplier" [{importanceMultiplier}]
ObjectEnd
AttributeBegin
Attribute "Ri" "int Matte" [0]
Attribute "identifier" "int id" [1] "string name" ["{lightName}"]
Attribute "lighting" "int mute" [0]
Attribute "trace" "int holdout" [0]
Attribute "user" "string __materialid" ["{lightName}"]
Attribute "visibility" "int camera" [{ri_visiblecamera}] "int indirect" [{ri_indirect}] "int transmission" [{ri_visibletransmission}]
Transform [ {lightTransformationMatrix} ]
ObjectInstance "{lightId}"
AttributeEnd
"""
extra_rect_light = '\n"string lightColorMap" ["{lightColorMap}"] "vector colorMapGamma" [{colorMapGamma}] "float colorMapSaturation" [{colorMapSaturation}]'
